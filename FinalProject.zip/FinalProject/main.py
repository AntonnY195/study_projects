field = [[" "] * 3 for i in range(3) ]
round_number = 0

def display_field():
    print("  0 1 2")
    for i in range(3):
        row = " ".join(field[i])
        print(f"{i} {row}")

def user_input():
    while True:
        user_coords = input("Input your coordinates:  ").split()
        if len(user_coords) != 2:
            print("Input *2* coordinates: ")
            continue

        x, y = user_coords

        if not(x.isdigit()) or not(y.isdigit()):
            print("Input *numbers*: ")
            continue

        x, y = int(x), int(y)

        if 0 > x or x > 2 or 0 > y or y >2 :
            print("Input *correct* coordinates: ")
            continue

        if field[x][y] != " " :
            print("Cell already taken, choose another: ")
            continue

        return x, y

def check_win_cond():
    win_combos = [((0, 0), (0, 1), (0, 2)),
                  ((1, 0),(1, 1), (1, 2)),
                  ((2, 0), (2, 1), (2, 2)),
                  ((0, 0), (1, 0), (2, 0)),
                  ((0, 1), (1, 1), (2, 1)),
                  ((0, 2), (1, 2), (2, 2)),
                  ((0, 0), (1, 1), (2, 2)),
                  ((0, 2), (1, 1), (2, 0))]
    for combo in win_combos:
        symbols = []
        for a in combo:
            symbols.append(field[a[0]][a[1]])
        if symbols == ["X", "X", "X"]:
            print("X won!")
            return True
        if symbols == ["O", "O", "O"]:
            print("Y won!")
            return True
    return False

while True:
    round_number += 1

    display_field()

    if round_number % 2 == 1:
        print(" X turn")
    else:
        print(" O turn")

    x, y = user_input()


    if round_number % 2 == 1:
        field[x][y] = "X"
    else:
        field[x][y] = "O"

    if round_number == 9:
        print("Draw!")
        break

    if check_win_cond():
        break



